import paho.mqtt.client as mqtt

# MQTT broker details
broker_address = "localhost"
broker_port = 1883
client_id = "mqtt_server"

# Callback function for connection status
def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected to MQTT broker!")
        client.subscribe("Airtel")  # Subscribe to a specific topic
    else:
        print("Connection failed. RC:", rc)

# Callback function for received messages
def on_message(client, userdata, msg):
    print("Received message:", msg.payload.decode())

# Create MQTT client
client = mqtt.Client(client_id=client_id)

# Set callback functions
client.on_connect = on_connect
client.on_message = on_message

# Connect to MQTT broker
client.connect(broker_address, broker_port, 60)

# Start the MQTT network loop
client.loop_start()

# Publish a message (optional)
client.publish("Airtel", "Hello, MQTT!")

# Keep the program running
while True:
    pass

# Disconnect from MQTT broker
client.loop_stop()
client.disconnect()