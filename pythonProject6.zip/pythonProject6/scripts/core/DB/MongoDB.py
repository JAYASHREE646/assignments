from pymongo import MongoClient
from pydantic import BaseModel

from main import app_main

client = MongoClient("mongodb://intern_23:intern%40123@192.168.0.220:2717/interns_b2_23")

db = client.interns_b2_23

inventory = db.Jayashree_inventory





@app_main.get("/")
def welcome():
    return {"Welcome to library!"}


@app_main.get("/book_all")
def read_book():
    course = (inventory.find())
    new_course = []
    for student in course:
        del student["_id"]
        new_course.append(student)
    return new_course


@app_main.post("/book/{'book_id'}")
def create_book(book: Book):
    inventory.insert_one(book.dict())
    return {"created"}


@app_main.put("/book/{book_id}")
def update_book(book_id: str, book: Book):
    inventory.update_one({"book_id": book_id}, {"$set": book.dict()})
    return {"updated"}


@app_main.delete("/books/{name}")
def delete_book(name: str):
    inventory.delete_one({"name": name})
    return {"deleted"}
