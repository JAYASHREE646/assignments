from fastapi import APIRouter

from scripts.core.DB.MongoDB import Book
from scripts.core.handlers.Book_handler import Book_handler

book_router = APIRouter()
book_object = Book_handler()


@book_router.get("/")
def read_book():
    all_book = book_object.get_data()
    return all_book


@book_router.post("/book/{'book_id'}")
def create_data(book: Book):
    all_book = book_object.create_data(book)
    return all_book


@book_router.put("/book/{book_id}")
def update_book(book_id: str, book: Book):
    all_book = book_object.update_book(book_id, book)
    return book_id


@book_router.delete("/books/{name}")
def delete_book(name: str):
    all_book = book_object.delete_data()
    return all_book
