from fastapi import APIRouter
from schemas.models import Book, Email
from scripts.core.handlers.Book_handler import welcome, read_book, create_book, update_book, delete_book, pipeline_agg
from scripts.core.handlers.email_handler import send_email


app = APIRouter()


@app.get("/")
def fun():
    return welcome()


@app.get("/book_all")
def fun():
    return read_book()


@app.post("/book/{'book_id'}")
def fun(book: Book):
    return create_book(book)


@app.put("/book/{book_id}")
def fun(book_id: str, book: Book):
    return update_book(book_id, book)


@app.delete("/books/{name}")
def fun(name: str):
    return delete_book(name)

@app.post("/send_email")
def fun(email: Email):
    total_amount = pipeline_agg()
    return send_email(str(total_amount), email)

@app.get("/Total_price")
def fun():
    return pipeline_agg()