from schemas.models import Book
from utility.mong_utility import inventory


def welcome():
    return {"Welcome to library!"}


def read_book():
    try:
        course = (inventory.find())
        new_course = []
        for student in course:
            del student["_id"]
            new_course.append(student)
        return new_course
    except Exception as e:
        return "error", str(e)


def create_book(book: Book):
    try:
        if list(inventory.find({"name": book.name})) != []:
            return {'message': 'Book already present'}

        else:
            inventory.insert_one(book.dict())
            return {"created"}
    except Exception as e:
        return {"Error is generated": str(e)}


def update_book(name: int, book: Book):
    try:
        inventory.update_one({"name": name}, {"$set": book.dict()})
        return {"updated"}
    except Exception as e:
        return {"error in the statement": str(e)}


def delete_book(name: str):
    try:
        inventory.delete_one({"name": name})
        return {"deleted"}
    except Exception as e:
        return {"error in the statement": str(e)}


def pipeline_agg():
    pipeline = [
        {
            '$addFields': {
                'Total_Price': {
                    '$multiply': [
                        '$quanity', '$price'
                    ]
                }
            }
        }, {
            '$group': {
                '_id': None,
                'Overall_book_amount_collected': {
                    '$sum': '$Total_Price'
                }
            }
        }, {
            '$project': {
                '_id': 0
            }
        }
    ]
    data = inventory.aggregate(pipeline)
    data = list(data)
    print(data)
    return {"Overall_Book_Borrowed_amount": data[0]['Overall_book_amount_collected']}
