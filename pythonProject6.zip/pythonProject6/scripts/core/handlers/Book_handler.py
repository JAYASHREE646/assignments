from scripts.core.DB.MongoDB import read_book, create_book, update_book, delete_book, Book


class Book_handler():
    def get_data(self):
        return read_book()

    def post_data(self, book: Book):
        return create_book(book)

    def put_data(self, book_id: str, book: Book):
        return update_book(book_id)

    def delete_data(self, name: str):
        return delete_book(name)

    def create_data(self, book):
        pass

    def update_book(self, book_id, book):
        pass
