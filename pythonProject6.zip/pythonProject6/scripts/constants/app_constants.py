class Book_end:
    get_books = "/book_all"
    create_books = "/book/{'book_id'}"
    update_books = "/book/{book_id}"
    delete_books = "/books/{name}"
    send_mail = "/send_email"
    pipeline_arg = "/Total_price"





