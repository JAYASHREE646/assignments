from fastapi import FastAPI
from scripts.core.services.service_book import app

app_main = FastAPI()

app_main.include_router(app)

import uvicorn

if __name__ == "__main__":
    uvicorn.run("main:app_main", reload=True)
