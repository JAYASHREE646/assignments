import uvicorn
from fastapi import FastAPI

from scripts.core.services.service_book import book_router

app = FastAPI()
app.include_router(book_router)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)

# class Book(BaseModel):
# name: str
# category: str
# borrower_name: str


# @app.get("/")
# def welcome():
# return {"Welcome to library!"}


# @app.get("/book_all")
# def read_book():
# course = (inventory.find())
# new_course = []
# for student in course:
# del student["_id"]
# new_course.append(student)
# return new_course


# @app.post("/book/{'book_id'}")
# def create_book(book: Book):
# inventory.insert_one(book.dict())
# return {"created"}

# @app.put("/book/{book_id}")
# def update_book(book_id: str, book: Book):
# inventory.update_one({"book_id":book_id},{"$set": book.dict()})
# return {"updated"}


# @app.delete("/books/{name}")
# def delete_book(name: str):
# inventory.delete_one({"name": name})
# return {"deleted"}
