from fastapi import FastAPI
from scripts.core.services.service_book import app as inventory

app_main = FastAPI()

app_main.include_router(inventory)

import uvicorn

if __name__ == "__main__":
    uvicorn.run("main:app_main")
