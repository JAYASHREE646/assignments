import json

with open("sample_data.json") as file:
    para = json.load(file)
    for each_item in para:
        if each_item == "parameters":
            parameter_list = para[each_item]
    data_list = []
    parameters = para["parametersList"]
    for each_item in parameters:
        details = {"parameterName": each_item["parameterName"], "min_value": each_item["min"],
                   "max_value": each_item["max"], "avg_value": each_item["avg"]}
        data_list.append(details)
    json_store = json.dumps(data_list, indent=3)
    print(json_store)
